sap.ui.define([
	"chuck/norris/jokes/controller/BaseController"
], function(BaseController) {
	"use strict";

	return BaseController.extend("chuck.norris.jokes.controller.App", {

		onInit: function() {
			

		}
	});

});